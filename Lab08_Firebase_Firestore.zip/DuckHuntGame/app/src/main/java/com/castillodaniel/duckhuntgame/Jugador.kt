package com.castillodaniel.duckhuntgame

data class Jugador(var usuario: String, var patosCazados: Int) {
    constructor() : this("", 0)
}